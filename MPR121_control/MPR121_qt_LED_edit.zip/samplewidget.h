#ifndef SAMPLEWIDGET_H
#define SAMPLEWIDGET_H

#include <QPushButton>


class SampleWidget : public QPushButton
{
public:
    SampleWidget(QWidget *parent = 0);
};

#endif // SAMPLEWIDGET_H
