#include "samplewidget.h"

SampleWidget::SampleWidget(QWidget *parent):
    QPushButton(parent)
{
    setText("sampleWidget");
}
