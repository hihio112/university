#include "mainwindow.h"

#include "ui_mainwindow.h"
#define UART_SG_MPR_READ_REG 'm' // 0x6D




MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow), settingWindow(new SettingDialog)
{


    ui->setupUi(this);

    setWindowTitle(tr("UART FILTER"));

    // default setting
    ui->pbsend->setEnabled(false);
    ui->pbset->setEnabled(true);


    //custom plotsetting

    //ui->customplot->xAxis->setRange(0,100);
    //ui->customplot->yAxis->setRange(0,230);
    //ui->customplot->addGraph();
    //ui->customplot->addGraph();
    //ui->customplot->graph(0)->setPen(QPen(Qt::red));
    //ui->customplot->graph(0)->setData(x,y);




    // UART setup
    this->m_SerialPort = new QSerialPort(this);
    this->m_SerialPort->setReadBufferSize(3);
    connect(this->m_SerialPort, SIGNAL(readyRead()), this, SLOT(LOOPBACK()));

    // setup window
    connect(this->settingWindow, SIGNAL(applied_setting()), this, SLOT(set_setting()));

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pbsend_clicked()
{



        if(ui->pbconnect->text() == "DISCONNECT")
        {
            // it can be clicked when uart is connect
                ui->pbsend->setEnabled(true);
                ui->pbset->setEnabled(false);
                Cmd_Str = ui->line->text();
                //Cmd = Cmd_Str.toUtf8();
                Cmd = Cmd_Str.toLocal8Bit();
                this->m_SerialPort -> write(Cmd);
                qDebug()<<Cmd_Str <<Cmd;
                /*
                qint64 A=this->m_SerialPort -> bytesToWrite();
                QString tmp = QString::number(A);
                qDebug() << tmp;
                */ //write when you want to check write buffer
            return ;
        }
        else return ;
}

void MainWindow::on_pbset_clicked()
{
    this->settingWindow->show();
}

void MainWindow::on_pbconnect_clicked()
{
        if (ui->pbconnect->text()=="CONNECT")
        {
            // have not connected
            // Another Things
            // Serial port Setting
            UART temp = this->settingWindow->getUART();
            this->m_SerialPort->setPortName(temp.getName());
            this->m_SerialPort->setBaudRate(temp.getBaudRate());
            this->m_SerialPort->setDataBits(temp.getDataBits());
            this->m_SerialPort->setParity(temp.getParity());
            this->m_SerialPort->setStopBits(temp.getStopBits());
            this->m_SerialPort->setFlowControl(temp.getFlowControl());

            // open Serial Port
            if(this->m_SerialPort->open(QIODevice::ReadWrite))
            {
                // serial port is opened
                ui->pbconnect->setToolTip("Click to Disconnect UART");
                ui->pbconnect->setText("DISCONNECT");
                ui->pbsend->setEnabled(true); // make runPB enable
                //Debug, check its property
                QSerialPortInfo port_info_debug(*this->m_SerialPort);
                QString Name = "Name: ";
                Name.append(port_info_debug.portName());
            }
            else
            {
                // serial port is not opened
                QMessageBox::critical(this, tr("Error"), this->m_SerialPort->errorString());
            }
        }
        else
        {
            // connected already
            QMessageBox msgBox;
            msgBox.setText("Disconnect serial port");
            msgBox.setInformativeText("Are you sure?");
            msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::Cancel);
            msgBox.setDefaultButton(QMessageBox::Cancel);
            int ret = msgBox.exec();
            switch (ret)
            {
              case QMessageBox::Yes:
                // Yes was clicked--> disconnect
                if (this->m_SerialPort->isOpen())
                {
                    this->m_SerialPort->close();
                }
                //console->setEnabled(false);
                ui->pbconnect->setText("CONNECT");
                ui->pbconnect->setToolTip("Click to connect UART.");
                ui->pbsend->setEnabled(false);
                break;
              case QMessageBox::Cancel:
                // Cancel was clicked
                break;
              default:
                // should never be reached
                break;
            }
        }
}

void MainWindow::LOOPBACK()
{
    /*
     *
     *
     * QByteArray Data = this->m_SerialPort->read(8);
    QString str0 = "Point: ";
    QString str1 = "Cos: ";
    QString str2 = "Sin: ";
    std::reverse(Data.begin(),Data.end());
    QByteArray Data1 = Data.mid(0,4);
    QByteArray Data2 = Data.mid(4);
    float cos;
    float sin;
    double X;
    memcpy(&sin,Data.data(),4);
    memcpy(&cos,Data2.data(),4);
    str0.append(QString::number(this->cnt+1));
    str1.append(QString::number(cos));
    str2.append(QString::number(sin));
    ui->textBrowser->append(str0);
    ui->textBrowser->append(str1);
    ui->textBrowser->append(str2);
     */



        QByteArray head = this->m_SerialPort->read(1); // use another function
        QByteArray MPR_Data_0,MPR_Data_1;
        head =head.toHex(' ');
        //qDebug()<<head;

            this->m_SerialPort->waitForReadyRead();
            MPR_Data_0 = this->m_SerialPort->read(1);
            //this->m_SerialPort->waitForReadyRead();
            MPR_Data_1 = this->m_SerialPort->read(1);
            //qDebug()<<MPR_Data_0;
            MPR_Data_0 =MPR_Data_0.toHex(' ');
            MPR_Data_1 =MPR_Data_1.toHex(' ');
            //qDebug()<<"zero"<<MPR_Data_0<<"one"<<MPR_Data_1;
            //qDebug()<<MPR_Data[1];

    /*
            QString picture = ":bt0:bt1:bt2:bt3:bt4:bt5:bt6:bt7:bt8:bt9:bt10:bt11";
            QString bt0 = ": ";
            QString bt1 = "  : ";
            QString bt2 = "  : ";
            QString bt3 = "  : ";
            QString bt4 = "  : ";
            QString bt5 = "  : ";
            QString bt6 = "  : ";
            QString bt7 = "  : ";
            QString bt8 = "  : ";
            QString bt9 = "  : ";
            QString bt10 = "  : ";
            QString bt11 = "  : ";
    */
            //qDebug()<<"zero_of_zero"<<MPR_Data_0[0]<<"one_of_zero"<<MPR_Data_0[1];
            //qint64 bt_11;
            QPixmap static led_on("/QTworkspace/MPR121_qt/LED_ON");
            QPixmap static led_off("/QTworkspace/MPR121_qt/LED_OFF");

            //btn 0~3
            if((MPR_Data_1[1]=='1' )||(MPR_Data_1[1]=='3')||(MPR_Data_1[1]=='5')||(MPR_Data_1[1]=='7')||(MPR_Data_1[1]=='9')||(MPR_Data_1[1]=='b')||(MPR_Data_1[1]=='d')||(MPR_Data_1[1]=='f'))
            {
                //bt0.append("on");
                ui->led_0->setPixmap(led_on);

            }
            else{
                //bt0.append("off");
                ui->led_0->setPixmap(led_off);
            }
            if((MPR_Data_1[1]=='2' )||(MPR_Data_1[1]=='3')||(MPR_Data_1[1]=='6')||(MPR_Data_1[1]=='a')||(MPR_Data_1[1]=='e')||(MPR_Data_1[1]=='f')||(MPR_Data_1[1]=='b')||(MPR_Data_1[1]=='7'))
            {
                //bt1.append("on");
                ui->led_1->setPixmap(led_on);
            }
            else{
                //bt1.append("off");
                ui->led_1->setPixmap(led_off);
            }
            if((MPR_Data_1[1]=='4' )||(MPR_Data_1[1]=='5')||(MPR_Data_1[1]=='6')||(MPR_Data_1[1]=='7')||(MPR_Data_1[1]=='c')||(MPR_Data_1[1]=='d')||(MPR_Data_1[1]=='e')||(MPR_Data_1[1]=='f'))
            {
                //bt2.append("on");
                ui->led_2->setPixmap(led_on);
            }
            else{
                //bt2.append("off");
                ui->led_2->setPixmap(led_off);
            }
            if((MPR_Data_1[1]=='f' )||(MPR_Data_1[1]=='a')||(MPR_Data_1[1]=='b')||(MPR_Data_1[1]=='c')||(MPR_Data_1[1]=='d')||(MPR_Data_1[1]=='e')||(MPR_Data_1[1]=='9')||(MPR_Data_1[1]=='8'))
            {
                //bt3.append("on");
                ui->led_3->setPixmap(led_on);
            }
            else
            {
                //bt3.append("off");
                ui->led_3->setPixmap(led_off);
            }

            //btn 4~7
            if((MPR_Data_1[0]=='1' )||(MPR_Data_1[0]=='3')||(MPR_Data_1[0]=='5')||(MPR_Data_1[0]=='7')||(MPR_Data_1[0]=='9')||(MPR_Data_1[0]=='b')||(MPR_Data_1[0]=='d')||(MPR_Data_1[0]=='f'))
            {
                //bt4.append("on");
                ui->led_4->setPixmap(led_on);
            }
            else{
                //bt4.append("off");
                ui->led_4->setPixmap(led_off);
            }
            if((MPR_Data_1[0]=='2' )||(MPR_Data_1[0]=='3')||(MPR_Data_1[0]=='6')||(MPR_Data_1[0]=='a')||(MPR_Data_1[0]=='e')||(MPR_Data_1[0]=='f')||(MPR_Data_1[0]=='b')||(MPR_Data_1[0]=='7'))
            {
                //bt5.append("on");
                ui->led_5->setPixmap(led_on);
            }
            else{
                //bt5.append("off");
                ui->led_5->setPixmap(led_off);
            }
            if((MPR_Data_1[0]=='4' )||(MPR_Data_1[0]=='5')||(MPR_Data_1[0]=='6')||(MPR_Data_1[0]=='7')||(MPR_Data_1[0]=='c')||(MPR_Data_1[0]=='d')||(MPR_Data_1[0]=='e')||(MPR_Data_1[0]=='f'))
            {
                //bt6.append("on");
                ui->led_6->setPixmap(led_on);
            }
            else{
                //bt6.append("off");
                ui->led_6->setPixmap(led_off);
            }
            if((MPR_Data_1[0]=='f' )||(MPR_Data_1[0]=='a')||(MPR_Data_1[0]=='b')||(MPR_Data_1[0]=='c')||(MPR_Data_1[0]=='d')||(MPR_Data_1[0]=='e')||(MPR_Data_1[0]=='9')||(MPR_Data_1[0]=='8'))
            {
                //bt7.append("on");
                ui->led_7->setPixmap(led_on);
            }
            else
            {
                //bt7.append("off");
                ui->led_7->setPixmap(led_off);
            }

            //btn 8~11
            if((MPR_Data_0[1]=='1' )||(MPR_Data_0[1]=='3')||(MPR_Data_0[1]=='5')||(MPR_Data_0[1]=='7')||(MPR_Data_0[1]=='9')||(MPR_Data_0[1]=='b')||(MPR_Data_0[1]=='d')||(MPR_Data_0[1]=='f'))
            {
                //bt8.append("on");
                ui->led_8->setPixmap(led_on);
            }
            else{
                //bt8.append("off");
                ui->led_8->setPixmap(led_off);
            }
            if((MPR_Data_0[1]=='2' )||(MPR_Data_0[1]=='3')||(MPR_Data_0[1]=='6')||(MPR_Data_0[1]=='a')||(MPR_Data_0[1]=='e')||(MPR_Data_0[1]=='f')||(MPR_Data_0[1]=='b')||(MPR_Data_0[1]=='7'))
            {
                //bt9.append("on");
                ui->led_9->setPixmap(led_on);
            }
            else{
                //bt9.append("off");
                ui->led_9->setPixmap(led_off);
            }
            if((MPR_Data_0[1]=='4' )||(MPR_Data_0[1]=='5')||(MPR_Data_0[1]=='6')||(MPR_Data_0[1]=='7')||(MPR_Data_0[1]=='c')||(MPR_Data_0[1]=='d')||(MPR_Data_0[1]=='e')||(MPR_Data_0[1]=='f'))
            {
               // bt10.append("on");
                ui->led_10->setPixmap(led_on);
            }
            else{
                //bt10.append("off");
                ui->led_10->setPixmap(led_off);
            }
            if((MPR_Data_0[1]=='f' )||(MPR_Data_0[1]=='a')||(MPR_Data_0[1]=='b')||(MPR_Data_0[1]=='c')||(MPR_Data_0[1]=='d')||(MPR_Data_0[1]=='e')||(MPR_Data_0[1]=='9')||(MPR_Data_0[1]=='8'))
            {
                //bt11.append("on");
                ui->led_11->setPixmap(led_on);
            }
            else
            {
               // bt11.append("off");
                ui->led_11->setPixmap(led_off);
            }



            //qDebug()<<"bt0"<<bt0<<"bt1"<<bt1<<"bt2"<<bt2<<"bt3"<<bt3<<"bt4"<<bt4<<"bt5"<<bt5<<"bt6"<<bt6<<"bt7"<<bt7<<"bt8"<<bt8<<"bt9"<<bt9<<"bt10"<<bt10<<"bt11"<<bt11;

    /*
           QString str0 = "bt0";
           QString str1 = "bt1";
           QString str2 = "bt2";
           QString str3 = "bt3";
           QString str4 = "bt4";
           QString str5 = "bt5";
           QString str6 = "bt6";
           QString str7 = "bt7";
           QString str8 = "bt8";
           QString str9 = "bt9";
           QString str10 = "bt10";
           QString str11 = "bt11";



           str0.append(bt0);
           str1.append(bt1);
           str2.append(bt2);
           str3.append(bt3);
           str4.append(bt4);
           str5.append(bt5);
           str6.append(bt6);
           str7.append(bt7);
           str8.append(bt8);
           str9.append(bt9);
           str10.append(bt10);
           str11.append(bt11);

           str0.append(" | ");
           str0.append(str1);
           str0.append(" | ");
           str0.append(str2);
           str0.append(" | ");
           str0.append(str3);
           str0.append(" | ");
           str0.append(str4);
           str0.append(" | ");
           str0.append(str5);
           str0.append(" | ");
           str0.append(str6);
           str0.append(" | ");
           str0.append(str7);
           str0.append(" | ");
           str0.append(str8);
           str0.append(" | ");
           str0.append(str9);
           str0.append(" | ");
           str0.append(str10);
           str0.append(" | ");
           str0.append(str11);
           ui->textBrowser->append(str0);
      */
//};


        QThread::msleep(2);


};


    /*
    else if(Cmd_Str==QString("Q")) {
        char Data_origin;
        memcpy(&Data_origin,rxdata.data(),1);
        QString str = "value :";
        unsigned char r_Data_1 = static_cast<unsigned char>(Data_origin);
        qDebug()<<"CHECK";
        r_x.append(r_i);
        r_y.append(r_Data_1);
        r_i=r_i+1;
        ui->customplot->graph(1)->setData(r_x,r_y);
        ui->customplot->replot();

        str.append(QString::number(r_Data_1));
        ui->textBrowser->append(str);

        QString Str = "Q"; // 0x52
        QByteArray Cmd = Str.toLocal8Bit();
        QThread::msleep(1);
        this->m_SerialPort -> write(Cmd);
    }

}*/

void MainWindow::set_setting()
{
    QString str1 = "Name: ";
    QString str2 = "BaurdRate: ";
    QString str3 = "DataBits: ";
    QString str4 = "Parity: ";
    QString str5 = "StopBits: ";
    QString str6 = "FlowControl: ";
    QString str7 = "LocalEchoEnabled: ";
    str1.append(this->settingWindow->m_UART->getName());
    str2.append(this->settingWindow->m_UART->getBaudRateStr());
    str3.append(this->settingWindow->m_UART->getDataBitsStr());
    str4.append(this->settingWindow->m_UART->getParityStr());
    str5.append(this->settingWindow->m_UART->getStopBitsStr());
    str6.append(this->settingWindow->m_UART->getFlowControlStr());
    str7.append(this->settingWindow->m_UART->getLocalEchoEnabled());
    ui->textBrowser->append("<UART Settings>");
    ui->textBrowser->append(str1);
    ui->textBrowser->append(str2);
    ui->textBrowser->append(str3);
    ui->textBrowser->append(str4);
    ui->textBrowser->append(str5);
    ui->textBrowser->append(str6);
    ui->textBrowser->append(str7);
}

void MainWindow::on_pbclear_clicked()
{
    ui->textBrowser->clear();
    ui->line->clear();
    /*
    ui->customplot->graph(0)->data().data()->clear();
    ui->customplot->graph(1)->data().data()->clear();
    ui->customplot->replot();
    */
}
