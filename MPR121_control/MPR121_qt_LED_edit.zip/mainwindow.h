#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMessageBox>
#include <QThread>
#include <QDebug>
#include "settingdialog.h"
#include "uart.h"
#include "qcustomplot.h"
#include <QPen>
#include <QPixmap>
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:

    void on_pbsend_clicked();

    void on_pbset_clicked();

    void on_pbconnect_clicked();

    void LOOPBACK();

    void set_setting();

    void on_pbclear_clicked();

private:
    Ui::MainWindow *ui;
    SettingDialog *settingWindow;

    QSerialPort *m_SerialPort;
    bool send_check;

    int i = 0; //experiment
    int r_i = 0;
    QVector<double> x, y;  //vector for store data;
    QVector<double> r_x, r_y;
    QString Cmd_Str;
    QByteArray Cmd;

};
#endif // MAINWINDOW_H
