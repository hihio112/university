#pragma once
#include <iostream>
#include <vector>

using namespace std;

struct node {
    string characters;
    int frequency;
    string code;
    int depth;
    node* parent;
    node* leftchild;
    node* rightchild;
    int node_number;
};

vector<node*> node_array;
vector<int> number_array;
int cnt = 1;
int cnt_b;
void get_adaptive_huffmantree(node* root, string i_str);
node* find_str(string i_str) {
    node* target = NULL;
    for (int i = 0; i < node_array.size(); i++) {
        if (node_array[i]->characters == i_str) {
            target = node_array[i];
        }
    }
    return target;

}

node* add_new_character(string s) {
    node* position = new node;
    position = find_str("NEW");
    if (position == NULL)
        cout << "������";

    node* newnode = new node;
    newnode->characters = "NEW";
    newnode->frequency = 0;
    newnode->leftchild = NULL;
    newnode->rightchild = NULL;
    newnode->depth = position->depth + 1;
    newnode->parent = position;
    newnode->node_number = cnt;
    node_array.push_back(newnode);
    cnt++;

    node* stnode = new node;
    stnode->characters = s;
    stnode->frequency = 1;
    stnode->leftchild = NULL;
    stnode->rightchild = NULL;
    stnode->depth = position->depth + 1;
    stnode->parent = position;
    stnode->node_number = cnt;
    node_array.push_back(stnode);
    cnt++;

    position->frequency = 1;
    position->rightchild = stnode;
    position->leftchild = newnode;
    position->characters = "";


    return position;
}

void frequency_update(node* search) {

    node* target = search;
    while (1) {
        if (target->parent == NULL)
            break;
        else if (target->parent->rightchild == NULL || target->parent->leftchild == NULL)
            break;
        else {
            //cout << "frequency update\n";
            target->parent->frequency = target->parent->leftchild->frequency + target->parent->rightchild->frequency;
            target = target->parent;
        }
    }

}


node* SwapNode(node* a, node* b) {
    //a�� �� �ؿ� �ִ� �� depth�� ŭ.���ų�
    node tempnode;
    tempnode.characters = a->characters;
    tempnode.frequency = a->frequency;
    tempnode.leftchild = a->leftchild;
    tempnode.rightchild = a->rightchild;
    tempnode.parent = a->parent;

    a->characters = b->characters;
    a->frequency = b->frequency;
    a->parent = b->parent;
    a->leftchild = b->leftchild;
    a->rightchild = b->rightchild;

    b->characters = tempnode.characters;
    b->frequency = tempnode.frequency;
    b->parent = tempnode.parent;
    b->leftchild = tempnode.leftchild;
    b->rightchild = tempnode.rightchild;
    return a;

}

void print_vector() {
    cout << "\t" << "data" << "\t" << "count" << endl;
    cout << "\t" << "-----------------------------------" << endl;
    for (int i = 0; i < node_array.size(); i++) {
        if (node_array[i]->characters != "NEW" && node_array[i]->characters != "")
            cout << "\t" << node_array[i]->characters << "\t" << node_array[i]->frequency << endl;
    }
}


node* first_update(node* first_node) {
    int t_depth = first_node->depth;
    int t_frequency = first_node->frequency;
    //first_node�� depth���� ���� �� �߿��� first_node�� frequency���� ���� �� �߿� ���� ū�� �� node�� �ٲ����. 
    node* t_node = NULL;
    for (int i = 0; i < node_array.size(); i++) {
        if (node_array[i]->depth < t_depth && node_array[i]->frequency < t_frequency && node_array[i]->characters != "") {
            if (t_node == NULL) {
                t_node = node_array[i];
                //cout << ""endl;
            }
            else if (t_node->frequency < node_array[i]->frequency) {
                t_node = node_array[i];

            }
        }
    }
    if (t_node != NULL) {
        t_node = SwapNode(first_node, t_node);
        //cout << "���� ������ �ִ� ���\n";
    }
    else if (first_node->parent != NULL && first_node->parent->leftchild != NULL && first_node->parent->rightchild != NULL) {
        if (first_node->parent->leftchild->frequency > first_node->parent->rightchild->frequency) {
            t_node = SwapNode(first_node->parent->leftchild, first_node->parent->rightchild);
            //cout << "���� ���� �� �ִ� ���\n";
        }
    }
    return t_node;
}

node* second_update(node* search) {
    node* x = search;
    if (x == NULL)
        return NULL;
    else if (x->parent == NULL)
        return NULL;
    else if (x->parent->parent == NULL)
        return NULL;
    else {
        if (x->parent->parent->leftchild != NULL && x->parent->parent->rightchild != NULL) {
            if (x->parent->parent->leftchild->frequency > x->parent->parent->rightchild->frequency) {
                SwapNode(x->parent->parent->leftchild, x->parent->parent->rightchild);
            }
        }
    }

}


void get_adaptive_huffman_code() {

    cout << "adaptive huffman coding" << endl;


    node* root = new node;
    root->depth = 1;
    root->leftchild = NULL;
    root->rightchild = NULL;
    root->frequency = 0;
    root->parent = NULL;
    root->characters = "NEW";
    root->node_number = 1;
    cnt++;

    node_array.push_back(root);
    number_array.push_back(1);
    string str;
    while (true) {
        cout << "your input : ";
        cin >> str;
        if (str == "quit") {
            break;
        }
        else {
            get_adaptive_huffmantree(root, str);
        }
    }
}

void depthFirstSearch(node* tempRoot, string s)
{
    node* root1 = new node;
    root1 = tempRoot;

    root1->code = s;
    if (root1 == NULL)
    {

    }
    else if (root1->leftchild == NULL && root1->rightchild == NULL)
    {
        cout << "\t" << root1->characters << "\t" << root1->code << endl;
    }
    else
    {
        root1->leftchild->code = s.append("0");
        s.erase(s.end() - 1);
        root1->rightchild->code = s.append("1");
        s.erase(s.end() - 1);

        depthFirstSearch(root1->leftchild, s.append("0"));
        s.erase(s.end() - 1);
        depthFirstSearch(root1->rightchild, s.append("1"));
        s.erase(s.end() - 1);
    }
}
void print_test() {
    for (int i = 0; i < node_array.size(); i++) {
        if (node_array[i]->leftchild != NULL && node_array[i]->rightchild != NULL)
            cout << "node_number" << node_array[i]->node_number << " character:" << node_array[i]->characters << " frequency" << node_array[i]->frequency << " right:" << node_array[i]->rightchild->characters << " left:" << node_array[i]->leftchild->characters << "depth: " << node_array[i]->depth;
        else if (node_array[i]->leftchild != NULL)
            cout << "node_number" << node_array[i]->node_number << "character:" << node_array[i]->characters << " frequency" << node_array[i]->frequency << " left:" << node_array[i]->leftchild->characters << "depth: " << node_array[i]->depth;
        else if (node_array[i]->rightchild != NULL)
            cout << "node_number" << node_array[i]->node_number << "character:" << node_array[i]->characters << " frequency" << node_array[i]->frequency << " right:" << node_array[i]->rightchild->characters << "depth: " << node_array[i]->depth;
        else
            cout << "node_number" << node_array[i]->node_number << "character:" << node_array[i]->characters << " frequency" << node_array[i]->frequency << "depth: " << node_array[i]->depth;
        if (node_array[i]->parent != NULL)
            cout << "parent" << node_array[i]->parent->node_number << endl;
    }
}

//������ �ִ��� Ȯ��-> ���� ���� �߰� and �Ʒ����� frequency ��ü
void get_adaptive_huffmantree(node* root, string i_str) {
    node* tempnode = root;
    if (tempnode->rightchild == NULL && tempnode->leftchild == NULL) {
        //ó���� ���
        node* newnode = new node;
        newnode->characters = "NEW";
        newnode->frequency = 0;
        newnode->leftchild = NULL;
        newnode->rightchild = NULL;
        newnode->depth = 2;
        newnode->parent = tempnode;
        newnode->node_number = 2;
        node_array.push_back(newnode);
        //number_array.push_back(2);
        cnt++;
        node* stnode = new node;
        stnode->characters = i_str;
        stnode->frequency = 1;
        stnode->leftchild = NULL;
        stnode->rightchild = NULL;
        stnode->depth = 2;
        stnode->parent = tempnode;
        stnode->node_number = 3;
        node_array.push_back(stnode);
        //number_array.push_back(3);
        cnt++;

        tempnode->frequency = 1;
        tempnode->rightchild = stnode;
        tempnode->leftchild = newnode;
        tempnode->characters = "";
    }
    else {
        //ó���� �ƴѰ�� ������ �ִ��� üũ
        node* search = new node;
        node* freqency = new node;
        node* target;
        search = find_str(i_str);
        if (search != NULL) {
            //������ �ִ� ���
            search->frequency = search->frequency + 1;
            freqency = first_update(search);
            if (freqency != NULL)
                frequency_update(freqency);
            cnt_b = cnt;
            while (1) {
                second_update(search);
                if (search->parent == NULL || cnt_b == 0) {
                    break;
                }
                else {
                    search = search->parent;
                    cnt_b -= 1;
                }
            }
        }
        else {
            //������ ���� ���
            search = add_new_character(i_str);
            while (1) {
                second_update(search);
                if (search->parent == NULL || cnt_b == 0) {
                    break;
                }
                else {
                    search = search->parent;
                    cnt_b -= 1;
                }
            }
        }
    }
    print_vector();
    cout << endl << endl;
    cout << "\t" << "data" << "\t" << "code" << endl;
    cout << "\t" << "----------------------" << endl;
    node* temp_root = new node;
    for (int i = 0; i < node_array.size(); i++) {
        if (node_array[i]->node_number == 1)
            temp_root = node_array[i];
    }
    //print_test();
    depthFirstSearch(temp_root, "");
}