#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow), settingWindow(new SettingDialog)
{

    //int i = 0;
    /*
    for(int i=0;i<100;i++)
    {
        x[i] = i;
        y[i] = i;
    }*/                 //test

    ui->setupUi(this);
    setWindowTitle(tr("UART FILTER"));

    // default setting
    ui->pbsend->setEnabled(false);
    ui->pbset->setEnabled(true);


    //custom plotsetting

    ui->customplot->xAxis->setRange(0,100);
    ui->customplot->yAxis->setRange(0,230);
    ui->customplot->addGraph();
    ui->customplot->addGraph();
    ui->customplot->graph(0)->setPen(QPen(Qt::red));
    //ui->customplot->graph(0)->setData(x,y);




    // UART setup
    this->m_SerialPort = new QSerialPort(this);
    connect(this->m_SerialPort, SIGNAL(readyRead()), this, SLOT(LOOPBACK()));

    // setup window
    connect(this->settingWindow, SIGNAL(applied_setting()), this, SLOT(set_setting()));

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pbsend_clicked()
{



        if(ui->pbconnect->text() == "DISCONNECT")
        {
            // it can be clicked when uart is connect
                ui->pbsend->setEnabled(true);
                ui->pbset->setEnabled(false);
                Cmd_Str = ui->line->text();
                //Cmd = Cmd_Str.toUtf8();
                Cmd = Cmd_Str.toLocal8Bit();
                this->m_SerialPort -> write(Cmd);
                qDebug()<<Cmd_Str <<Cmd;
                /*
                qint64 A=this->m_SerialPort -> bytesToWrite();
                QString tmp = QString::number(A);
                qDebug() << tmp;
                */ //write when you want to check write buffer
            return ;
        }
        else return ;
}

void MainWindow::on_pbset_clicked()
{
    this->settingWindow->show();
}

void MainWindow::on_pbconnect_clicked()
{
        if (ui->pbconnect->text()=="CONNECT")
        {
            // have not connected
            // Another Things
            // Serial port Setting
            UART temp = this->settingWindow->getUART();
            this->m_SerialPort->setPortName(temp.getName());
            this->m_SerialPort->setBaudRate(temp.getBaudRate());
            this->m_SerialPort->setDataBits(temp.getDataBits());
            this->m_SerialPort->setParity(temp.getParity());
            this->m_SerialPort->setStopBits(temp.getStopBits());
            this->m_SerialPort->setFlowControl(temp.getFlowControl());

            // open Serial Port
            if(this->m_SerialPort->open(QIODevice::ReadWrite))
            {
                // serial port is opened
                ui->pbconnect->setToolTip("Click to Disconnect UART");
                ui->pbconnect->setText("DISCONNECT");
                ui->pbsend->setEnabled(true); // make runPB enable
                //Debug, check its property
                QSerialPortInfo port_info_debug(*this->m_SerialPort);
                QString Name = "Name: ";
                Name.append(port_info_debug.portName());
            }
            else
            {
                // serial port is not opened
                QMessageBox::critical(this, tr("Error"), this->m_SerialPort->errorString());
            }
        }
        else
        {
            // connected already
            QMessageBox msgBox;
            msgBox.setText("Disconnect serial port");
            msgBox.setInformativeText("Are you sure?");
            msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::Cancel);
            msgBox.setDefaultButton(QMessageBox::Cancel);
            int ret = msgBox.exec();
            switch (ret)
            {
              case QMessageBox::Yes:
                // Yes was clicked--> disconnect
                if (this->m_SerialPort->isOpen())
                {
                    this->m_SerialPort->close();
                }
                //console->setEnabled(false);
                ui->pbconnect->setText("CONNECT");
                ui->pbconnect->setToolTip("Click to connect UART.");
                ui->pbsend->setEnabled(false);
                break;
              case QMessageBox::Cancel:
                // Cancel was clicked
                break;
              default:
                // should never be reached
                break;
            }
        }
}

void MainWindow::LOOPBACK()
{
    /*
     *
     *
     * QByteArray Data = this->m_SerialPort->read(8);
    QString str0 = "Point: ";
    QString str1 = "Cos: ";
    QString str2 = "Sin: ";
    std::reverse(Data.begin(),Data.end());
    QByteArray Data1 = Data.mid(0,4);
    QByteArray Data2 = Data.mid(4);
    float cos;
    float sin;
    double X;
    memcpy(&sin,Data.data(),4);
    memcpy(&cos,Data2.data(),4);
    str0.append(QString::number(this->cnt+1));
    str1.append(QString::number(cos));
    str2.append(QString::number(sin));
    ui->textBrowser->append(str0);
    ui->textBrowser->append(str1);
    ui->textBrowser->append(str2);
     */


    QByteArray  rxdata= this->m_SerialPort->read(1);

    if(Cmd_Str==QString("R")){
        char Data;
        memcpy(&Data,rxdata.data(),1);
        QString str = "value :";
        unsigned char r_Data = static_cast<unsigned char>(Data);
        //qDebug() << reinterpret_cast<unsigned int>(rxdata[0]);
        //ui->textBrowser->append((Data[a]));
        //qDebug() << Data[a];
        //str.append(QString::number(Data));
        //str.append("______");
        //x[i] =
        x.append(i);
        y.append(r_Data);
        i=i+1;
        ui->customplot->graph(0)->setData(x,y);
        ui->customplot->replot();

        str.append(QString::number(r_Data));
        ui->textBrowser->append(str);

        //ui->textBrowser->append("ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ");
        //ui->textBrowser->append(int(rxdata));
        QString Str_re = "R"; // 0x52
        QByteArray Cmd_re = Str_re.toLocal8Bit();
        QThread::msleep(1);
        this->m_SerialPort -> write(Cmd_re);
        qDebug()<<"CHECK_R";
}
    else if(Cmd_Str==QString("Q")) {
        char Data_origin;
        memcpy(&Data_origin,rxdata.data(),1);
        QString str = "value :";
        unsigned char r_Data_1 = static_cast<unsigned char>(Data_origin);
        qDebug()<<"CHECK";
        r_x.append(r_i);
        r_y.append(r_Data_1);
        r_i=r_i+1;
        ui->customplot->graph(1)->setData(r_x,r_y);
        ui->customplot->replot();

        str.append(QString::number(r_Data_1));
        ui->textBrowser->append(str);

        QString Str = "Q"; // 0x52
        QByteArray Cmd = Str.toLocal8Bit();
        QThread::msleep(1);
        this->m_SerialPort -> write(Cmd);
    }

}

void MainWindow::set_setting()
{
    QString str1 = "Name: ";
    QString str2 = "BaurdRate: ";
    QString str3 = "DataBits: ";
    QString str4 = "Parity: ";
    QString str5 = "StopBits: ";
    QString str6 = "FlowControl: ";
    QString str7 = "LocalEchoEnabled: ";
    str1.append(this->settingWindow->m_UART->getName());
    str2.append(this->settingWindow->m_UART->getBaudRateStr());
    str3.append(this->settingWindow->m_UART->getDataBitsStr());
    str4.append(this->settingWindow->m_UART->getParityStr());
    str5.append(this->settingWindow->m_UART->getStopBitsStr());
    str6.append(this->settingWindow->m_UART->getFlowControlStr());
    str7.append(this->settingWindow->m_UART->getLocalEchoEnabled());
    ui->textBrowser->append("<UART Settings>");
    ui->textBrowser->append(str1);
    ui->textBrowser->append(str2);
    ui->textBrowser->append(str3);
    ui->textBrowser->append(str4);
    ui->textBrowser->append(str5);
    ui->textBrowser->append(str6);
    ui->textBrowser->append(str7);
}

void MainWindow::on_pbclear_clicked()
{
    ui->textBrowser->clear();
    ui->line->clear();
    /*
    ui->customplot->graph(0)->data().data()->clear();
    ui->customplot->graph(1)->data().data()->clear();
    ui->customplot->replot();
    */
}
