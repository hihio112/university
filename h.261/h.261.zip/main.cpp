﻿#define _CRT_SECURE_NO_WARNINGS //fopen 오류 해결
#include <stdio.h> // FILE*, fseek, fread 등 사용
#include <iostream>
#include <vector>
#include <math.h>
#include <string>
#include <cstdio>
#include <map>
#define DATA_OFFSET_OFFSET 0x000A
#define WIDTH_OFFSET 0x0012
#define HEIGHT_OFFSET 0x0016
#define BITS_PER_PIXEL_OFFSET 0x001C
#define HEADER_SIZE 14
#define INFO_HEADER_SIZE 40
#define NO_COMPRESION 0
#define MAX_NUMBER_OF_COLORS 0
#define ALL_COLORS_REQUIRED 0

using namespace std;

const double PI = 3.1415926;

typedef unsigned int int32;
typedef short int16;
typedef unsigned char byte;
#define MV_NUMBER 16 
#define P_VALUE 15 
#define V_num 25
#define GOP_num 5

typedef struct bitfiled {
    unsigned b0 : 1;
    unsigned b1 : 1;
    unsigned b2 : 1;
    unsigned b3 : 1;
    unsigned b4 : 1;
    unsigned b5 : 1;
    unsigned b6 : 1;
    unsigned b7 : 1;
};


struct RLC_data {
    int value;
    int skip;
    int size;
    string value_code;
    string run_size_code;
};

struct MBlock {
    int data[8][8];
    int zig_data[64] = { 0 };
    vector<RLC_data> RLC_group;
};

struct DC_data {
    string size_code;
    string value_code;
    int size;
    int value;
};

struct frame_data {
    vector<int> DCgroup;
    vector<MBlock> MBgroup;
    vector <DC_data> DC_datagroup;
};

struct x_y {
    short x;
    short y;
};

vector<MBlock> MBgroup;
vector <frame_data> frame_data_group;

vector <unsigned char**> frame_group;

int qt[8][8] = {
    {16,11,10,16,24,40,51,61},
    {12,12,14,19,26,58,60,55},
    {14,13,16,24,40,57,69,56},
    {14,17,22,29,51,87,80,62},
    {18,22,37,56,68,109,103,77},
    {24,35,55,64,81,104,113,92},
    {49,64,78,87,103,121,120,101},
    {72,92,95,98,112,100,103,99}
};


void MakeRawData(byte** pixel_pointer, byte** raw_data, int32 width, int32 height, int32 bytesPerPixel) {
    int unpaddedRowSize = width * bytesPerPixel;
    int totalSize = unpaddedRowSize * height;
    for (int i = 0; i < V_num; i++) {
        raw_data[i] = new byte[totalSize / 3];
        for (int p = 0; p < totalSize/3; p = p + 1) {
            raw_data[i][p] = pixel_pointer[i][p*3];
        }
    }
   
}

unsigned char** Img_1Dto2D(byte* pixels, int width, int height, int32 bytesPerPixel) {
    int unpaddedRowSize = width * bytesPerPixel;
    int realRowSize = unpaddedRowSize / 3;
    int totalSize = unpaddedRowSize * height;
    unsigned char** result = new unsigned char*[height];
    for (int i = 0; i < height; i++) {
        result[i] = new unsigned char[width];
        for (int j = 0; j < width; j++) {
            result[i][j] = pixels[realRowSize * i + j];
        }
    }

    return result;
}




//unsigned char 데이터를 MV_NUMBER*MV_NUMBER 블록에 (m,n)에서부터 MV_NUMBER, MV_NUMBER범위를 넣어주는 함수
void Div_ImgBlock_MV(unsigned char** data, unsigned char** block, int m, int n)
{
    for (int i = 0; i < MV_NUMBER; i++)
    {
        for (int j = 0; j < MV_NUMBER; j++)
        {
            block[i][j] = data[m + i][n + j];
        }
    }
}


void Get_MotionVector(vector<x_y>& moVec, unsigned char** r_frame, unsigned char** t_frame, int width, int height)
{
    moVec.clear();
    short mv_x = 0, mv_y = 0, x = 0, y = 0;
    unsigned char** cp_block_r = new unsigned char* [MV_NUMBER];
    for (int i = 0; i < MV_NUMBER; i++)
        cp_block_r[i] = new unsigned char[MV_NUMBER];
    unsigned char** cp_block_t = new unsigned char* [MV_NUMBER];
    for (int i = 0; i < MV_NUMBER; i++)
        cp_block_t[i] = new unsigned char[MV_NUMBER];


    for (int i = 0; i < height / MV_NUMBER; i++)
    {
        for (int j = 0; j < width / MV_NUMBER; j++)
        {
            x = j * MV_NUMBER;
            y = i * MV_NUMBER;
            int diff = INT_MAX;
            x_y temp_xy;
            for (mv_y = -1 * P_VALUE; mv_y < P_VALUE; mv_y++)
            {
                for (mv_x = -1 * P_VALUE; mv_x < P_VALUE; mv_x++)
                {
                    if (((y + mv_y) >= 0) && ((y + mv_y) <= (height - MV_NUMBER)) && ((x + mv_x) >= 0) && ((x + mv_x) <= (width - MV_NUMBER)))
                    {
                        int temp = 0;
                        Div_ImgBlock_MV(r_frame, cp_block_r, y + mv_y, x + mv_x);
                        Div_ImgBlock_MV(t_frame, cp_block_t, y, x);
                        for (int k = 0; k < MV_NUMBER; k++)
                        {
                            for (int l = 0; l < MV_NUMBER; l++)
                            {
                                temp += abs((int)cp_block_r[k][l] - (int)cp_block_t[k][l]);
                            }
                        }
                        if (temp < diff)
                        {
                            diff = temp;
                            temp_xy.x = mv_x;
                            temp_xy.y = mv_y;
                        }
                    }
                }
            }
            moVec.push_back(temp_xy);
        }
    }

    for (int i = 0; i < MV_NUMBER; i++)
        delete[] cp_block_t[i];
    delete[] cp_block_t;
    for (int i = 0; i < MV_NUMBER; i++)
        delete[] cp_block_r[i];
    delete[] cp_block_r;
}

unsigned char** Get_PredictedImg(vector<x_y>& moVec, unsigned char** r_frame, int width, int height) {
    unsigned char** temp = r_frame;
    int x, y;
    int order=0;
    int mov_x, mov_y;
    unsigned char** result = new unsigned char* [height];
    for (int i = 0; i < height; i++) {
        result[i] = new unsigned char[width];
    }
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            result[i][j] = r_frame[i][j];
        }
    }
  
    
    for (int i = 0; i < height; i = i + MV_NUMBER)
    {
        for (int j = 0; j < width; j = j + MV_NUMBER)
        {
            mov_x = moVec[order].x;
            mov_y = moVec[order].y;
            result[i][j] = r_frame[i + mov_y][j + mov_x];
            order++;
        }
    }
    return result;
}

//=============================================================================================================





void ReadImage(const char* fileName, const char* outfileName, byte** pixels, int32* width, int32* height, int32* bytesPerPixel, FILE*& imageFile, FILE*& OUT) // (파일이름, 픽셀값 담을 배열, 가로길이 값의 시작 위치, 세로길이 값의 시작 위치, 픽셀당 바이트 수 시작 위치
{
    imageFile = fopen(fileName, "rb");
    int32 dataOffset; 
    int32 LookUpTable=0; 
    fseek(imageFile, HEADER_SIZE + INFO_HEADER_SIZE-8, SEEK_SET); 
    fread(&LookUpTable, 4, 1, imageFile);
    fseek(imageFile, 0, SEEK_SET);
    OUT = fopen(outfileName, "wb");
    int header = 0;
    if (LookUpTable)
        header = HEADER_SIZE + INFO_HEADER_SIZE + 1024;
    else
        header = HEADER_SIZE + INFO_HEADER_SIZE;
    for (int i = 0; i < header; i++) 
    {
        int get = getc(imageFile);
        putc(get, OUT);
    }
    fseek(imageFile, DATA_OFFSET_OFFSET, SEEK_SET); 
    fread(&dataOffset, 4, 1, imageFile); 
    fseek(imageFile, WIDTH_OFFSET, SEEK_SET);
    fread(width, 4, 1, imageFile);
    fseek(imageFile, HEIGHT_OFFSET, SEEK_SET);
    fread(height, 4, 1, imageFile);
    int16 bitsPerPixel;
    fseek(imageFile, BITS_PER_PIXEL_OFFSET, SEEK_SET);
    fread(&bitsPerPixel, 2, 1, imageFile);
    *bytesPerPixel = ((int32)bitsPerPixel) / 8; 

    int paddedRowSize = (int)(4 * (float)(*width) / 4.0f) * (*bytesPerPixel); 
    int unpaddedRowSize = (*width) * (*bytesPerPixel);
    int totalSize = unpaddedRowSize * (*height);

    *pixels = new byte[totalSize];
    int i = 0;
    byte* currentRowPointer = *pixels + ((*height - 1) * unpaddedRowSize);
    for (i = 0; i < *height; i++)
    {
        fseek(imageFile, dataOffset + (i * paddedRowSize), SEEK_SET);       
        fread(currentRowPointer, 1, unpaddedRowSize, imageFile);            
        currentRowPointer -= unpaddedRowSize;
    }
    
    fclose(imageFile);
}

void WriteImage(byte* pixels, int32 width, int32 height, int32 bytesPerPixel, FILE*& outputFile)
{
    int paddedRowSize = (int)(4 * (float)width / 4.0f) * bytesPerPixel;
    int unpaddedRowSize = width * bytesPerPixel;
    for (int i = 0; i < height; i++)
    {
        int pixelOffset = ((height - i) - 1) * unpaddedRowSize;
        for (int i = 0; i < paddedRowSize; i++) {
            fwrite(&pixels[pixelOffset + i], 1, 1, outputFile);
        }
    }    
    fclose(outputFile);
}

void readMacroBlock(byte* pixels, int32 width, int32 height, int32 bytesPerPixel) 
{
    int unpaddedRowSize = width * bytesPerPixel;
    int first_pt;
    MBlock mb;
    for (int colum = 0; colum < unpaddedRowSize/3; colum = colum + 8) {
        for (int row = 0; row < height; row = row + 8) {
            first_pt = row * unpaddedRowSize/3 + colum;
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    mb.data[i][j] = pixels[first_pt + unpaddedRowSize/3 * i + j];
                }
            }
            MBgroup.push_back(mb);
        }
    }
}

void readMacroBlock_P(unsigned char** pixels, int32 width, int32 height) {
    MBlock mb;
    for (int y = 0; y < height; y = y+8) {
        for (int x = 0; x < width; x = x + 8) {
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    mb.data[i][j] = pixels[y+i][x+j];
                }
            }
            MBgroup.push_back(mb);
            

        }
    }
}

void DCT() {
    MBlock temp;
    double cu;
    double cv;
    for (int num = 0; num < MBgroup.size(); num++) {
        for (int i = 0; i < 8; i++) {
            if (i == 0) {
                cu = 1.0 / sqrt(2);
            }
            else {
                cu = 1;
            }
            for (int j = 0; j < 8; j++) {
                if (j == 0) {
                    cv = 1.0 / sqrt(2);
                }
                else {
                    cv = 1;
                }
                double sum = 0.0;
                for (int a = 0; a < 8; a++) {
                    for (int b = 0; b < 8; b++) {
                        //sum += cos((2 * a + 1) * i * PI / 16 + (2 * b + 1) * j * PI / 16) * (MBgroup[num].data[a][b]);
                        sum += cos((2 * a + 1) * i * PI / 16) * cos((2 * b + 1) * j * PI / 16) * (MBgroup[num].data[a][b]-128);
                    }
                }
                temp.data[i][j] = sum * cu * cv / 4;
            }
        }
        MBgroup[num] = temp;
    }
}

void quantization() {
    for (int num = 0; num < MBgroup.size(); num++) {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                MBgroup[num].data[i][j] = MBgroup[num].data[i][j] / qt[i][j];
            }
        }
    }
}

void zigzag() {
    //0,0 1,0 0,1 0,2 1,1 2,0 3,0 2,1 1,2 0,3 순서로
    int x;
    int y;
    int mode;
    for (int num = 0; num < MBgroup.size();num++)
    {   
        x = 0;
        y = 0;
        mode = 0;
        for (int i = 0; i < 64; i++) {
            MBgroup[num].zig_data[i] = MBgroup[num].data[y][x];
            if ((x == 0) && (y == 0)) {
                x = 1;
            }
            else if (mode == 0) {
                if (y == 7) {
                    x += 1;
                    mode = 1;
                }
                else if (x == 0) {
                    y += 1;
                    mode = 1;
                }
                else {
                    x -= 1;
                    y += 1;
                }
            }
            else {
                if (x == 7) {
                    y += 1;
                    mode = 0;
                }
                else if (y == 0) {
                    x += 1;
                    mode = 0;
                }
                else {
                    y -= 1;
                    x += 1;
                }
            }
        }
    }
}

frame_data dpcm() {
    frame_data temp;
    temp.MBgroup = MBgroup;
    for (int num = 0; num < MBgroup.size(); num++) {
        if (num == 0) {
            temp.DCgroup.push_back(MBgroup[num].zig_data[0]);
        }
        else {
            temp.DCgroup.push_back(MBgroup[num].zig_data[0] - MBgroup[num - 1].zig_data[0]);
        }
    }
    return temp;
}

string DC_Length_Table(int size) {
    string result;
    switch(size){
    case 0: 
        result = "00";
        break;
    case 1:
        result = "010";
        break;
    case 2:
        result = "011";
        break;
    case 3:
        result = "100";
        break;
    case 4:
        result = "101";
        break;
    case 5:
        result = "110";
        break;
    case 6:
        result = "1110";
        break;
    case 7:
        result = "11110";
        break;
    case 8:
        result = "111110";
        break;
    case 9:
        result = "1111110";
        break;
    case 10:
        result = "11111110";
        break;
    case 11:
        result = "111111110";
        break;
    }
    return result;
}

string DC_Value_Table(int value, int size) {
    int data = value;
    string result;
    int sign_flag;
    if (value >= 0) {
        sign_flag = 1;
    }
    else {
        sign_flag = 0;
    }

    if (data == 0) {
        result = "";
    }
    else {
        for (int i = size-1; i >= 0; i--) {
            int bit = (abs(data) >> i) & 1;
            if (sign_flag) {
                if (bit) {
                    result.append("1");
                }
                else {
                    result.append("0");
                }
            }
            else {
                if (bit) {
                    result.append("0");
                }
                else {
                    result.append("1");
                }
            }
        }
    }
    return result;
}

frame_data DC_huffman(frame_data temp_frame_data) {
    int size;
    int value;
    DC_data temp;
    frame_data result = temp_frame_data;
    for (int num = 0; num < result.DCgroup.size(); num++) {
        value = result.DCgroup[num];
        if (value == 0) {
            size = 0;
        }
        else {
            size = log(abs(value)) / log(2) + 1;
        }
        temp.size = size;
        temp.value = value;
        temp.size_code = DC_Length_Table(size);
        temp.value_code = DC_Value_Table(value, size);
        result.DC_datagroup.push_back(temp);
    }
    return result;
}

frame_data RLC(frame_data temp_frame_data) {
    int cnt;
    RLC_data data;
    frame_data temp=temp_frame_data;
    for (int num = 0; num < temp.MBgroup.size(); num++) {
        cnt = 0;
        for (int i = 1; i < 64; i++) {
            if (cnt == 15) {
                data.skip = cnt;
                data.value = temp.MBgroup[num].zig_data[i];
                cnt = 0;
                temp.MBgroup[num].RLC_group.push_back(data);
            }
            else if (temp.MBgroup[num].zig_data[i]==0) {
                if (i == 63) {
                    data.skip = cnt;
                    data.value = temp.MBgroup[num].zig_data[i];
                    cnt = 0;
                    temp.MBgroup[num].RLC_group.push_back(data);
                }
                else {
                    cnt += 1;
                }
            }
            else {
                data.skip = cnt;
                data.value = temp.MBgroup[num].zig_data[i];
                cnt = 0;
                temp.MBgroup[num].RLC_group.push_back(data);
            }
            if (i == 63) {  //end of block
                data.skip = 0;
                data.value = 0;
                temp.MBgroup[num].RLC_group.push_back(data);
            }
        }
    }
    return temp;
}

string AC_Value_Table(int value, int size) {
    int data = value;
    string result;
    int sign_flag;
    if (value >= 0) {
        sign_flag = 1;
    }
    else {
        sign_flag = 0;
    }

    if (data == 0) {
        result = "";
    }
    else {
        for (int i = size - 1; i >= 0; i--) {
            int bit = (abs(data) >> i) & 1;
            if (sign_flag) {
                if (bit) {
                    result.append("1");
                }
                else {
                    result.append("0");
                }
            }
            else {
                if (bit) {
                    result.append("0");
                }
                else {
                    result.append("1");
                }
            }
        }
    }
    return result;
}

string AC_Huffmantree(int runlength, int size) {
    static const std::map<std::pair<int, int>, std::string> str_map = {
        {{0, 0}, "1010"},
        {{0, 1}, "00"},
        {{0, 2}, "01"},
        {{0, 3}, "100"},
        {{0, 4}, "1011"},
        {{0, 5}, "11010"},
        {{0, 6}, "1111000"},
        {{0, 7}, "11111000"},
        {{0, 8}, "1111110110"},
        {{0, 9}, "1111111110000010"},
        {{0, 10},"1111111110000011"},
        
        {{1, 1}, "1100"},
        {{1, 2}, "11011"},
        {{1, 3}, "1111001"},
        {{1, 4}, "111110110"},
        {{1, 5}, "11111110110"},
        {{1, 6}, "1111111110000100"},
        {{1, 7}, "1111111110000101"},
        {{1, 8}, "1111111110000110"},
        {{1, 9}, "1111111110000111"},
        {{1, 10}, "1111111110001000"},

        {{2, 1}, "11100"},
        {{2, 2}, "11111001"},
        {{2, 3}, "1111110111"},
        {{2, 4}, "111111110100"},
        {{2, 5}, "1111111110001001"},
        {{2, 6}, "1111111110001010"},
        {{2, 7}, "1111111110001011"},
        {{2, 8}, "1111111110001100"},
        {{2, 9}, "1111111110001101"},
        {{2, 10}, "1111111110001110"},

        {{3, 1}, "111010"},
        {{3, 2}, "111110111"},
        {{3, 3}, "111111110101"},
        {{3, 4}, "1111111110001111"},
        {{3, 5}, "1111111110010000"},
        {{3, 6}, "1111111110010001"},
        {{3, 7}, "1111111110010010"},
        {{3, 8}, "1111111110010011"},
        {{3, 9}, "1111111110010100"},
        {{3, 10}, "1111111110010101"},
        
        {{4, 1}, "111011"},
        {{4, 2}, "1111111000"},
        {{4, 3}, "1111111110010110"},
        {{4, 4}, "1111111110010111"},
        {{4, 5}, "1111111110011000"},
        {{4, 6}, "1111111110011001"},
        {{4, 7}, "1111111110011010"},
        {{4, 8}, "1111111110011011"},
        {{4, 9}, "1111111110011100"},
        {{4, 10}, "1111111110011101"},

        {{5, 1}, "1111010"},
        {{5, 2}, "11111110111"},
        {{5, 3}, "1111111110011110"},
        {{5, 4}, "1111111110011111"},
        {{5, 5}, "1111111110100000"},
        {{5, 6}, "1111111110100001"},
        {{5, 7}, "1111111110100010"},
        {{5, 8}, "1111111110100011"},
        {{5, 9}, "1111111110100100"},
        {{5, 10}, "1111111110100101"},

        {{6, 1}, "1111011"},
        {{6, 2}, "111111110110"},
        {{6, 3}, "1111111110100110"},
        {{6, 4}, "1111111110100111"},
        {{6, 5}, "1111111110101000"},
        {{6, 6}, "1111111110101001"},
        {{6, 7}, "1111111110101010"},
        {{6, 8}, "1111111110101011"},
        {{6, 9}, "1111111110101100"},
        {{6, 10}, "1111111110101101"},

        {{7, 1}, "11111010"},
        {{7, 2}, "111111110111"},
        {{7, 3}, "1111111110101110"},
        {{7, 4}, "1111111110101111"},
        {{7, 5}, "1111111110110000"},
        {{7, 6}, "1111111110110001"},
        {{7, 7}, "1111111110110010"},
        {{7, 8}, "1111111110110011"},
        {{7, 9}, "1111111110110100"},
        {{7, 10}, "1111111110110101"},

        {{8, 1}, "111111000"},
        {{8, 2}, "111111111000000"},
        {{8, 3}, "1111111110110110"},
        {{8, 4}, "1111111110110111"},
        {{8, 5}, "1111111110111000"},
        {{8, 6}, "1111111110111001"},
        {{8, 7}, "1111111110111010"},
        {{8, 8}, "1111111110111011"},
        {{8, 9}, "1111111110111100"},
        {{8, 10}, "1111111110111101"},

        {{9, 1}, "111111001"},
        {{9, 2}, "1111111110111110"},
        {{9, 3}, "1111111110111111"},
        {{9, 4}, "1111111111000000"},
        {{9, 5}, "1111111111000001"},
        {{9, 6}, "1111111111000010"},
        {{9, 7}, "1111111111000011"},
        {{9, 8}, "1111111111000100"},
        {{9, 9}, "1111111111000101"},
        {{9, 10}, "1111111111000110"},

        {{10, 1}, "111111010"},
        {{10, 2}, "1111111111000111"},
        {{10, 3}, "1111111111001000"},
        {{10, 4}, "1111111111001001"},
        {{10, 5}, "1111111111001010"},
        {{10, 6}, "1111111111001011"},
        {{10, 7}, "1111111111001100"},
        {{10, 8}, "1111111111001101"},
        {{10, 9}, "1111111111001110"},
        {{10, 10}, "1111111111001111"},

        {{11, 1}, "1111111001"},
        {{11, 2}, "1111111111010000"},
        {{11, 3}, "1111111111010001"},
        {{11, 4}, "1111111111010010"},
        {{11, 5}, "1111111111010011"},
        {{11, 6}, "1111111111010100"},
        {{11, 7}, "1111111111010101"},
        {{11, 8}, "1111111111010110"},
        {{11, 9}, "1111111111010111"},
        {{11, 10}, "1111111111011000"},

        {{12, 1}, "1111111010"},
        {{12, 2}, "1111111111011001"},
        {{12, 3}, "1111111111011010"},
        {{12, 4}, "1111111111011011"},
        {{12, 5}, "1111111111011100"},
        {{12, 6}, "1111111111011101"},
        {{12, 7}, "1111111111011110"},
        {{12, 8}, "1111111111011111"},
        {{12, 9}, "1111111111100000"},
        {{12, 10}, "1111111111100001"},

        {{13, 1}, "11111111000"},
        {{13, 2}, "1111111111100010"},
        {{13, 3}, "1111111111100011"},
        {{13, 4}, "1111111111100100"},
        {{13, 5}, "1111111111100101"},
        {{13, 6}, "1111111111100110"},
        {{13, 7}, "1111111111100111"},
        {{13, 8}, "1111111111101000"},
        {{13, 9}, "1111111111101001"},
        {{13, 10}, "1111111111101010"},

        {{14, 1}, "1111111111101011"},
        {{14, 2}, "1111111111101100"},
        {{14, 3}, "1111111111101101"},
        {{14, 4}, "1111111111101110"},
        {{14, 5}, "1111111111101111"},
        {{14, 6}, "1111111111110000"},
        {{14, 7}, "1111111111110001"},
        {{14, 8}, "1111111111110010"},
        {{14, 9}, "1111111111110011"},
        {{14, 10}, "1111111111110100"},
        
        {{15, 1}, "1111111111110101"},
        {{15, 2}, "1111111111110110"},
        {{15, 3}, "1111111111110111"},
        {{15, 4}, "1111111111111000"},
        {{15, 5}, "1111111111111001"},
        {{15, 6}, "1111111111111010"},
        {{15, 7}, "1111111111111011"},
        {{15, 8}, "1111111111111100"},
        {{15, 9}, "1111111111111101"},
        {{15, 10}, "1111111111111110"},
        {{15, 0}, "11111111001"},
    };

    auto key = std::make_pair(runlength, size);
    auto it = str_map.find(key);
    if (it != str_map.end()) {
        return it->second;
    }
    else {
        return "";
    }
}


frame_data RLC_huffman(frame_data temp) {
    int size;
    frame_data result = temp;
    for (int num = 0; num < result.MBgroup.size(); num++) {
        for (int i = 0; i < result.MBgroup[num].RLC_group.size(); i++)
        {
            int value = result.MBgroup[num].RLC_group[i].value;
            if (value == 0) {
                size = 0;
            }
            else {
                size = log(abs(value)) / log(2) + 1;
            }
            int skip = result.MBgroup[num].RLC_group[i].skip;
            result.MBgroup[num].RLC_group[i].size = size;
            result.MBgroup[num].RLC_group[i].value_code = AC_Value_Table(value, size);
            result.MBgroup[num].RLC_group[i].run_size_code = AC_Huffmantree(skip, size);
        }
    }
    return result;
}//size와 value code 만들기



int main()
{
    byte** pixels_pointer = new byte * [V_num];
    byte** raw_data = new byte * [V_num];
    int32 width;
    int32 height;
    int32 bytesPerPixel;
    FILE** imageFile = new FILE * [V_num];
    FILE** outputFile = new FILE * [V_num];

//    char inputChar[V_num][50];
    char **outputChar = new char* [V_num];
    for (int i = 0; i < V_num; i++) {
        char input_char[50];
        char output_char[50];
        sprintf(input_char, "./Video/Video_Compression%02d.bmp", i+1);
        sprintf(output_char, "h.261_%02d.bmp", i+1);
        outputChar[i] = output_char;
        ReadImage(input_char, outputChar[i], &pixels_pointer[i], &width, &height, &bytesPerPixel, imageFile[i], outputFile[i]);
    }
    
    MakeRawData(pixels_pointer,raw_data, width, height, bytesPerPixel);
    int unpaddedRowSize = width * bytesPerPixel;

   
    string total_code = "";
    MBlock tempMB;
    //start of for loop for V_num =25 
    for (int k = 0; k < V_num; k=k + GOP_num) {
        printf("\n===========%d i-frame============",k);
        frame_data f_data;
        printf("\n=========== jpeg============");
        // ==================jpeg==========================
        readMacroBlock(raw_data[k], width, height, bytesPerPixel);
        DCT();
        quantization();
        zigzag();
        /*
        if (k == 0) {
            tempMB = MBgroup[80];
            cout << "MBlock[80] quantization" << endl;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    cout << tempMB.data[i][j] << "\t";
                }
                cout << "\n";
            }
        }
    */
        f_data.MBgroup = MBgroup;

        
        frame_data temp;
        temp = dpcm();
        f_data.DCgroup = temp.DCgroup;
        temp = DC_huffman(f_data);
        f_data.DC_datagroup = temp.DC_datagroup;
        temp = RLC(f_data);
        f_data.MBgroup = temp.MBgroup;
        temp = RLC_huffman(f_data);
        f_data.MBgroup = temp.MBgroup;
     
        for (int colum = 0; colum < unpaddedRowSize / 3; colum = colum + 8) {
            for (int row = 0; row < height; row = row + 8) {
                MBgroup.erase(MBgroup.begin());
            }
        }
        //DC code
        for (int i = 0; i < f_data.DC_datagroup.size(); i++)
        {
            total_code.append(f_data.DC_datagroup[i].size_code);
            total_code.append(f_data.DC_datagroup[i].value_code);
        }
        //AC code
        for (int i = 0; i < f_data.MBgroup.size(); i++) {
            for (int j = 0; j < f_data.MBgroup[i].RLC_group.size(); j++) {
                total_code.append(f_data.MBgroup[i].RLC_group[j].run_size_code);
                total_code.append(f_data.MBgroup[i].RLC_group[j].value_code);
            }
        }
 
  
        // ==================jpeg decoding========================== 
        // IDPCM
        for (int i = 1; i < f_data.DCgroup.size(); i++) {
            f_data.DCgroup[i] = f_data.DCgroup[i] + f_data.DCgroup[i - 1];
            f_data.MBgroup[i].zig_data[0] = f_data.DCgroup[i];
        }

        // RLC decompression 
        for (int i = 0; i < f_data.MBgroup.size(); i++) {
            int x = 1;
            for (int j = 0; j < f_data.MBgroup[i].RLC_group.size() - 1; j++) {
                int skip = f_data.MBgroup[i].RLC_group[j].skip;
                int value = f_data.MBgroup[i].RLC_group[j].value;
                for (int k = 0; k <= skip; k++) {
                    if (k == skip) {
                        f_data.MBgroup[i].zig_data[k + x] = value;
                        x += skip + 1;
                    }
                    else {
                        f_data.MBgroup[i].zig_data[k + x] = 0;
                    }
                }
            }
        }
 
        //inverse zigzag
        for (int i = 0; i < f_data.MBgroup.size(); i++) {
            int x = 0;
            int y = 0;
            int mode = 1;
            for (int j = 0; j < 64; j++) {
                f_data.MBgroup[i].data[y][x] = f_data.MBgroup[i].zig_data[j];
                if (mode == 0) {
                    if (y == 7) {
                        x += 1;
                        mode = 1;
                    }
                    else if (x == 0) {
                        y += 1;
                        mode = 1;
                    }
                    else {
                        x -= 1;
                        y += 1;
                    }
                }
                else {
                    if (x == 7) {
                        y += 1;
                        mode = 0;
                    }
                    else if (y == 0) {
                        x += 1;
                        mode = 0;
                    }
                    else {
                        y -= 1;
                        x += 1;
                    }
                }
            }
        }/*
        if (k == 0) {
            tempMB = f_data.MBgroup[80];
            cout << "MBlock[80] inverse zigzag " << endl;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    cout << tempMB.data[i][j] << "\t";
                }
                cout << "\n";
            }
        }*/
        //inverse quatization;
        for (int i = 0; i < f_data.MBgroup.size(); i++) {
            for (int x = 0; x < 8; x++) {
                for (int y = 0; y < 8; y++) {
                    f_data.MBgroup[i].data[y][x] = f_data.MBgroup[i].data[y][x] * qt[y][x];
                }
            }
        }/*
        if (k == 0) {
            tempMB = f_data.MBgroup[80];
            cout << "MBlock[80] inverse quantization " << endl;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    cout << tempMB.data[i][j] << "\t";
                }
                cout << "\n";
            }
        }*/
        //inverse DCT;
        for (int i = 0; i < f_data.MBgroup.size(); i++) {
            MBlock temp;
            for (int x = 0; x < 8; x++) {
                double sum;
                for (int y = 0; y < 8; y++) {
                    double cu, cv;
                    sum = 0;
                    for (int u = 0; u < 8; u++) {
                        for (int v = 0; v < 8; v++) {
                            if (u == 0)
                                cu = 1.0 / sqrt(2);
                            else
                                cu = 1;
                            if (v == 0)
                                cv = 1.0 / sqrt(2);
                            else
                                cv = 1.0;
                            sum += cos((2 * x + 1) * u * PI / 16) * cos((2 * y + 1) * v * PI / 16) * f_data.MBgroup[i].data[u][v] * cu * cv / 4;
                        }
                    }
                    temp.data[x][y] = (int)sum + 128;
                }
            }
            f_data.MBgroup[i] = temp;
        }
        /*
        if (k == 0) {
            tempMB = f_data.MBgroup[80];
            cout << "MBlock[80] IDCT " << endl;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    cout << tempMB.data[i][j] << "\t";
                }
                cout << "\n";
            }
        }*/

        //reconstruction of raw data;
        for (int colum = 0; colum < unpaddedRowSize / 3; colum = colum + 8) {
            int start;
            for (int row = 0; row < height; row = row + 8) {
                start = row * unpaddedRowSize / 3 + colum;
                MBlock temp = f_data.MBgroup[0];
                for (int i = 0; i < 8; i++) {
                    for (int j = 0; j < 8; j++) {
                        raw_data[k][start + unpaddedRowSize / 3 * i + j] = temp.data[i][j];
                    }
                }
                f_data.MBgroup.erase(f_data.MBgroup.begin());

            }
        }
        frame_data_group.push_back(f_data);



        vector <x_y> moVec;
        // ============================================p- frame compression==================================
        for (int j = 1; j < GOP_num; j++) {
            if (k + j == 25)
                break;
            printf("\n===========%d p_frame============", k + j);
            unsigned char** r_image = Img_1Dto2D(raw_data[k], width, height, bytesPerPixel);
            unsigned char** t_image = Img_1Dto2D(raw_data[k + j], width, height, bytesPerPixel);
            //motion vector
            frame_data p_data;

            Get_MotionVector(moVec, r_image, t_image, width, height);

            unsigned char** p_image = Get_PredictedImg(moVec, r_image, width, height);
            unsigned char** d_image = new unsigned char* [height];
            for (int t = 0; t < height; t++) {
                d_image[t] = new unsigned char[width];
                for (int q = 0; q < width; q++) {
                    d_image[t][q] = t_image[t][q] - p_image[t][q];
                }
            }
           
            readMacroBlock_P(d_image, width, height);
            //DCT
            DCT();
            //Quantize
            quantization();
            zigzag();
            
            temp = dpcm();
            
            p_data.DCgroup = temp.DCgroup;
            temp = DC_huffman(p_data);
            p_data.DC_datagroup = temp.DC_datagroup;
            temp = RLC(p_data);
            
            p_data.MBgroup = temp.MBgroup;
            temp = RLC_huffman(p_data);
            p_data.MBgroup = temp.MBgroup;
            int t = MBgroup.size();
            //printf("--------%d", temp.MBgroup.size());
            for (int a = 0; a < t; a++){
                    MBgroup.erase(MBgroup.begin());
             }
            
            //DC code
            for (int i = 0; i < p_data.DC_datagroup.size(); i++)
            {
                total_code.append(p_data.DC_datagroup[i].size_code);
                total_code.append(p_data.DC_datagroup[i].value_code);
            }
            //AC code
            for (int i = 0; i < p_data.MBgroup.size(); i++) {
                for (int j = 0; j < p_data.MBgroup[i].RLC_group.size(); j++) {
                    total_code.append(p_data.MBgroup[i].RLC_group[j].run_size_code);
                    total_code.append(p_data.MBgroup[i].RLC_group[j].value_code);
                }
            }
            printf("Compressed Data: %d\n", total_code.size());       


            for (int i = 0; i < height; i++)
                delete[] p_image[i];
            delete[] p_image;
            for (int i = 0; i < height; i++)
                delete[] r_image[i];
            delete[] r_image;
            for (int i = 0; i < height; i++)
                delete[] t_image[i];
            delete[] t_image;
        }
    }
    int Size = 304184 * V_num;
    printf("Compressed Data: %d\n", total_code.size());
    printf("Total Data before compress: %d\n", Size);
    printf("Compressed Data: %d\n", total_code.size());
    printf("compressed ratio: %f", (float)(Size / (float)total_code.size()));
    
    

    for (int u = 0; u < V_num; u++) {
        for (int i = 0; i < unpaddedRowSize * (height) / 3; i++) {
            pixels_pointer[u][3 * i] = raw_data[u][i];
            pixels_pointer[u][3 * i + 1] = raw_data[u][i];
            pixels_pointer[u][3 * i + 2] = raw_data[u][i];
        }
        WriteImage(pixels_pointer[u], width, height, bytesPerPixel, outputFile[u]);
    }
  
    FILE* o_file;
    o_file = fopen("binary.omh", "wb");
    for (int i = 0; i < total_code.size(); i = i + 8) {
        bitfiled bit;
        memset(&bit, 0, sizeof(bitfiled));
        bit.b0 = total_code[i];
        bit.b1 = total_code[i + 1];
        bit.b2 = total_code[i + 2];
        bit.b3 = total_code[i + 3];
        bit.b4 = total_code[i + 4];
        bit.b5 = total_code[i + 5];
        bit.b6 = total_code[i + 6];
        bit.b7 = total_code[i + 7];
        unsigned int cc = (bit.b0 * 128 + bit.b1 * 64 + bit.b2 * 32 + bit.b3 * 16 + bit.b4 * 8 + bit.b5 * 4 + bit.b6 * 2 + bit.b7);
        fwrite(&cc, 1, 1, o_file);
    }
    fclose(o_file);


    for (int i = 0; i < V_num; i++)
    {
        delete[] * (pixels_pointer + i);
    }
    delete[] pixels_pointer;
    return 0;
    
}